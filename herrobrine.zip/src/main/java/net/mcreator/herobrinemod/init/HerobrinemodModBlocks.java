
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.herobrinemod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.herobrinemod.block.HeadHerobrineBlock;
import net.mcreator.herobrinemod.HerobrinemodMod;

public class HerobrinemodModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, HerobrinemodMod.MODID);
	public static final RegistryObject<Block> HEAD_HEROBRINE = REGISTRY.register("head_herobrine", () -> new HeadHerobrineBlock());
}
